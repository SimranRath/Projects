package exercise7;

public interface Observer {
	void update(String stockName, double stockPrice);
}
