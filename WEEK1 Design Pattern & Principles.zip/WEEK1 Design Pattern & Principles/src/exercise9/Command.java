package exercise9;

public interface Command {
	void execute();
}
