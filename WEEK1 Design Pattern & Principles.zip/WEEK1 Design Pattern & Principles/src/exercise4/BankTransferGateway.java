package exercise4;

public class BankTransferGateway {
		    public void transferFunds(String accountNumber, double amount) {
		        System.out.println("Processing bank transfer for account " + accountNumber + ": $" + amount);
		    }
		}

