package exercise11;

public interface CustomerRepository {
	 Customer findCustomerById(int id);
}
