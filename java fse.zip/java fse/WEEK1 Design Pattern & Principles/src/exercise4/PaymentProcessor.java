package exercise4;

public interface PaymentProcessor {
	 void processPayment(String paymentMethod, double amount);
}
